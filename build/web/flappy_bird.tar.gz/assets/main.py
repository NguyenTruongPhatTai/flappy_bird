import asyncio
import pygame
from random import randint

pygame.init()
WIDTH, HEIGHT = 400, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird")

# Load assets
background = pygame.image.load("background.png")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))
bird_img = pygame.image.load("bird.png")
bird_img = pygame.transform.scale(bird_img, (40, 30))

# Game constants
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
TUBE_WIDTH = 50
TUBE_VELOCITY = 3
TUBE_GAP = 150
TUBE_DISTANCE = 200
GRAVITY = 0.5
BIRD_JUMP = -10
BIRD_X = 50

# Game state variables
score = 0
bird_y = 300
bird_drop_velocity = 0
clock = pygame.time.Clock()
game_over = False

# Tube positions
tube1_x = 400
tube2_x = tube1_x + TUBE_DISTANCE
tube3_x = tube2_x + TUBE_DISTANCE
tube1_height = randint(100, 400)
tube2_height = randint(100, 400)
tube3_height = randint(100, 400)
tube1_pass = tube2_pass = tube3_pass = False

# Font
font = pygame.font.SysFont('sans', 24)

# Reset function
def reset_game():
    global tube1_x, tube2_x, tube3_x, tube1_height, tube2_height, tube3_height
    global tube1_pass, tube2_pass, tube3_pass
    global bird_y, bird_drop_velocity, score, game_over

    tube1_x = 400
    tube2_x = tube1_x + TUBE_DISTANCE
    tube3_x = tube2_x + TUBE_DISTANCE
    tube1_height = randint(100, 400)
    tube2_height = randint(100, 400)
    tube3_height = randint(100, 400)
    tube1_pass = tube2_pass = tube3_pass = False

    bird_y = 300
    bird_drop_velocity = 0
    score = 0
    game_over = False

reset_game()

# --- Async game loop ---
async def main():
    global bird_y, bird_drop_velocity, tube1_x, tube2_x, tube3_x
    global tube1_height, tube2_height, tube3_height, tube1_pass, tube2_pass, tube3_pass
    global score, game_over

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if game_over:
                        reset_game()
                    else:
                        bird_drop_velocity = BIRD_JUMP

        if not game_over:
            # Move tubes
            tube1_x -= TUBE_VELOCITY
            tube2_x -= TUBE_VELOCITY
            tube3_x -= TUBE_VELOCITY

            # Bird gravity
            bird_y += bird_drop_velocity
            bird_drop_velocity += GRAVITY

            # Reset tubes
            if tube1_x < -TUBE_WIDTH:
                tube1_x = tube3_x + TUBE_DISTANCE
                tube1_height = randint(100, 400)
                tube1_pass = False
            if tube2_x < -TUBE_WIDTH:
                tube2_x = tube1_x + TUBE_DISTANCE
                tube2_height = randint(100, 400)
                tube2_pass = False
            if tube3_x < -TUBE_WIDTH:
                tube3_x = tube2_x + TUBE_DISTANCE
                tube3_height = randint(100, 400)
                tube3_pass = False

            # Check collisions
            tubes = [
                pygame.Rect(tube1_x, 0, TUBE_WIDTH, tube1_height),
                pygame.Rect(tube1_x, tube1_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube1_height - TUBE_GAP),
                pygame.Rect(tube2_x, 0, TUBE_WIDTH, tube2_height),
                pygame.Rect(tube2_x, tube2_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube2_height - TUBE_GAP),
                pygame.Rect(tube3_x, 0, TUBE_WIDTH, tube3_height),
                pygame.Rect(tube3_x, tube3_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube3_height - TUBE_GAP),
            ]
            bird_rect = bird_img.get_rect(center=(BIRD_X + 15, bird_y + 15))
            for t in tubes:
                if bird_rect.colliderect(t):
                    game_over = True
            if bird_y + bird_img.get_height() >= HEIGHT or bird_y <= 0:
                game_over = True

            # Update score
            if tube1_x + TUBE_WIDTH <= BIRD_X and not tube1_pass:
                score += 1
                tube1_pass = True
            if tube2_x + TUBE_WIDTH <= BIRD_X and not tube2_pass:
                score += 1
                tube2_pass = True
            if tube3_x + TUBE_WIDTH <= BIRD_X and not tube3_pass:
                score += 1
                tube3_pass = True

        # Draw
        screen.blit(background, (0, 0))
        pygame.draw.rect(screen, BLUE, (tube1_x, 0, TUBE_WIDTH, tube1_height))
        pygame.draw.rect(screen, BLUE, (tube2_x, 0, TUBE_WIDTH, tube2_height))
        pygame.draw.rect(screen, BLUE, (tube3_x, 0, TUBE_WIDTH, tube3_height))
        pygame.draw.rect(screen, BLUE, (tube1_x, tube1_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube1_height - TUBE_GAP))
        pygame.draw.rect(screen, BLUE, (tube2_x, tube2_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube2_height - TUBE_GAP))
        pygame.draw.rect(screen, BLUE, (tube3_x, tube3_height + TUBE_GAP, TUBE_WIDTH, HEIGHT - tube3_height - TUBE_GAP))
        screen.blit(bird_img, bird_rect)
        score_txt = font.render("Score: " + str(score), True, BLACK)
        screen.blit(score_txt, (10, 10))
        if game_over:
            over_txt = font.render("GAME OVER - Press SPACE to restart", True, BLACK)
            screen.blit(over_txt, (30, 270))
        pygame.display.flip()

        await asyncio.sleep(0)  # ráº¥t quan trá»�ng cho Pygbag

asyncio.run(main())
pygame.quit()
